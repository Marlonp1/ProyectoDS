/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package software;


import java.sql.*;
import javax.swing.JOptionPane;

public class Conexion {
    
    Connection con = null;
    
    public Conexion(){
        try{
            con = DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\ADMIN\\Documents\\NetBeansProjects\\Software\\DS.accdb");
            Statement st = con.createStatement(); 
            
           
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "No se pudo Conectar "+e);
        }
    }
    
    public Connection getConnection()
{
    return con;
}

}


